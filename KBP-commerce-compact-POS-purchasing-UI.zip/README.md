# KBP Compact Commerce Trading UI
- Compact scrollable product table for purchase invoices and POS (20+ lines).
- Item quantity is always editable; edit details opens one line only.
- Sticky review summary on wide screens, responsive stacked view on mobile.
- Backend review remains source of truth for taxes, discounts, currencies and final totals.
- Existing sale posting, purchase posting and print endpoint remain unchanged.
- Removed the exact phrase 'Business receipt. Not an official Rwanda EBM invoice.' from document markup.
- No database migration.
- Installer refuses conflicting local source edits. Backups under .kbp-patch-backups.
Verification: TSX syntax transpilation passed; full project typecheck and browser testing not run here.
