#!/usr/bin/env python3
"""Apply KBP compact trading UI without overwriting newer source changes."""
import argparse, hashlib, pathlib, shutil, sys, time, zipfile

PATH = "apps/web/components/commerce/CommerceTrading.tsx"
ORIGINAL_SHA = "122bf9f64cef6c34a868281f8ee967cf7c1c29e017550da6846bbd013c78ba35"
OUTPUT_SHA = "a63451099e3e1f3afafa20435dbd2910167ced3eaff3469500b62552c68431e7"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive")
    parser.add_argument("repo")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    repo = pathlib.Path(args.repo).resolve()
    target = repo / PATH
    if not (repo / "apps/web/package.json").is_file():
        sys.exit("STOP: Not a KBP repository root.")
    if not target.is_file():
        sys.exit("STOP: CommerceTrading.tsx is missing.")
    with zipfile.ZipFile(args.archive) as z:
        replacement = z.read("overlay/" + PATH)
    if digest(replacement) != OUTPUT_SHA:
        sys.exit("STOP: Patch content checksum is invalid.")
    actual = digest(target.read_bytes())
    if actual == OUTPUT_SHA:
        print("ALREADY APPLIED: No files changed.")
        return
    if actual != ORIGINAL_SHA:
        sys.exit("CONFLICT: Your local CommerceTrading.tsx differs from the source snapshot. No files were changed. Share the current file for a safe update.")
    print("CHECK OK: CommerceTrading.tsx matches the approved V45 UI snapshot.")
    if args.check:
        return
    backup_dir = repo / ".kbp-patch-backups" / ("compact-trading-" + time.strftime("%Y%m%d-%H%M%S"))
    backup = backup_dir / PATH
    backup.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(target, backup)
    tmp = target.with_name(target.name + ".kbp-compact-new")
    tmp.write_bytes(replacement)
    if digest(tmp.read_bytes()) != OUTPUT_SHA:
        tmp.unlink(missing_ok=True)
        sys.exit("STOP: Temporary output checksum mismatch.")
    tmp.replace(target)
    print("SUCCESS: Compact POS/Purchasing UI installed.")
    print("Backup:", backup)
    print("Next: cd apps/web && npx tsc --noEmit")

if __name__ == "__main__":
    main()
