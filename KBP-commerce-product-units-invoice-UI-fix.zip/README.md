# KBP Commerce UI correction — Product units and invoice review

This patch changes **only**:
- `apps/web/components/commerce/CommerceProductEditor.tsx`
- `apps/web/components/commerce/CommerceTrading.tsx`

## What changes

- Same Create/Edit product form with one Save button.
- Dropdowns for smallest tracked unit and purchase package, plus custom choices.
- Actual registered purchase price per crate/bag/etc., wholesale price per package, retail price per individual unit. Base cost is calculated internally.
- Additional configurable package sizes; fractional stock units default to allowed for measured products, not indivisible items.
- Preserves existing stock quantities and historical base units.
- Purchasing and POS continue to select registered catalog items.
- Explicit reason when Review is disabled (especially when branch/stock location is not selected).
- Clearly labeled Review -> Post / Complete -> Print workflow; auto-scroll to saved document details.
- Print/reprint remains available via Sales history. No new receipt or accounting transaction is created by printing.
- Fixes the unsafe `detail.supply_date` JSX condition from V45.

## Install (WSL Ubuntu, repo root)

Download this zip into Windows Downloads, and copy it to your repository.

```bash
cd /mnt/c/Users/k.yves/Desktop/projects/HMS
cp /mnt/c/Users/k.yves/Downloads/KBP-commerce-product-units-invoice-UI-fix.zip .
unzip -p KBP-commerce-product-units-invoice-UI-fix.zip apply.py > /tmp/kbp-ui-apply.py
python3 /tmp/kbp-ui-apply.py "$PWD/KBP-commerce-product-units-invoice-UI-fix.zip" "$PWD" --check
python3 /tmp/kbp-ui-apply.py "$PWD/KBP-commerce-product-units-invoice-UI-fix.zip" "$PWD"
```

If either command reports CONFLICT or STOP, do NOT overwrite the file manually. The local code may contain newer edits.

## Verify (Dev Container)

```bash
cd /workspace/apps/web
npx tsc --noEmit
```

No Flyway migration, backend restart, or database backup is needed for this UI-only patch. Running Next.js in dev mode should pick up changes automatically. The feature still requires the user's branch and stock location to be selected, core modules active, and an Accounting setup approval for posting.

### Important: Existing products with base unit CRATE

These cannot silently become BOTTLE-based inventory when they already have stock or documents. Create a new bottle-base product and reconcile historical stock through approved workflows.

### Verification scope

The archive was syntax-parsed and the guarded installer dry-run tested. Full Next.js typecheck, real browser printing and backend flow must be run in the user's actual WSL workspace.
