#!/usr/bin/env python3
"""Install the UI-only KBP patch without overwriting unrelated local edits."""
from pathlib import Path
import hashlib, json, re, sys, zipfile, shutil, datetime, tempfile, os

def sha(b): return hashlib.sha256(b).hexdigest()

def normalize_trading(content, original):
    if content==original: return content
    # Codex may have corrected the V45 unsafe JSX truthy check. Treat *only*
    # a changed supply-date boolean guard as an allowed upstream variation.
    marker=b'<p>Supplier date: {str(detail,"supply_date")}</p>}'
    prefix=b'{detail.kind==="PURCHASE"&&'
    end=content.find(marker)
    if end<0: return content
    start=content.rfind(prefix,0,end)
    if start<0 or end-start>240: return content
    normalized=content[:start]+prefix+b'detail.supply_date&&'+marker+content[end+len(marker):]
    return normalized

def main():
    if len(sys.argv)<3 or len(sys.argv)>4:
        print('Usage: python3 apply.py ZIP_PATH REPO_DIR [--check]');sys.exit(2)
    zpath=Path(sys.argv[1]);repo=Path(sys.argv[2]);check=len(sys.argv)==4 and sys.argv[3]=='--check'
    if len(sys.argv)==4 and not check:sys.exit('Unknown flag')
    if not (repo/'apps/web/package.json').is_file():sys.exit('STOP: Not a KBP repository root.')
    with zipfile.ZipFile(zpath) as z:
        manifest=json.loads(z.read('manifest.json'))
        patches={}
        for rel,info in manifest['files'].items():
            target=repo/rel
            if not target.is_file():sys.exit(f'STOP: Missing existing source file: {rel}')
            current=target.read_bytes();expected=z.read('baseline/'+rel)
            new=z.read('overlay/'+rel)
            if sha(current)==sha(new):
                print('ALREADY UPDATED:',rel);continue
            normalized=normalize_trading(current,expected) if rel.endswith('CommerceTrading.tsx') else current
            if sha(normalized)!=info['expected_v45_sha256']:
                print('CONFLICT:',rel)
                print('Local file differs from the reviewed V45 source beyond the known TypeScript fix.')
                print('Nothing has been modified. Keep your local changes; share the conflicting file to rebase the patch.')
                sys.exit(3)
            patches[rel]=(target,current,new)
        if not patches:
            print('ALREADY APPLIED: Both Commerce UI files are current.');return
        print('SAFE TO APPLY:',', '.join(patches))
        if check:
            print('CHECK PASSED. No files changed.');return
        backup=repo/'.kbp-patch-backups'/('UI-units-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
        backup.mkdir(parents=True,exist_ok=False)
        staged=[]
        try:
            for rel,(target,current,new) in patches.items():
                original_copy=backup/rel;original_copy.parent.mkdir(parents=True,exist_ok=True);original_copy.write_bytes(current)
                fd,tmp=tempfile.mkstemp(prefix='.kbp-ui-',dir=str(target.parent))
                os.close(fd);Path(tmp).write_bytes(new);os.chmod(tmp,target.stat().st_mode & 0o777)
                staged.append((target,tmp))
            for target,tmp in staged:os.replace(tmp,target)
        except Exception:
            for _,tmp in staged:
                if Path(tmp).exists():Path(tmp).unlink()
            # If an unexpected filesystem error occurs while replacing files,
            # restore all originals from the generated backups.
            for rel,(target,current,_) in patches.items():
                if target.exists() and target.read_bytes()!=current:target.write_bytes(current)
            raise
        print('APPLIED: Commerce UI patch installed.')
        print('Original source backed up at:',backup)
        print('No backend, database or migration changes were made.')

if __name__=='__main__':main()
