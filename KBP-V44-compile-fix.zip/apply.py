#!/usr/bin/env python3
"""Guarded install of three V44 compilation fixes; no database operations."""
from pathlib import Path
import sys,zipfile,hashlib,json,datetime,os
if len(sys.argv)!=3:raise SystemExit('Usage: python3 apply.py PATCH.zip /path/to/HMS')
archive=Path(sys.argv[1]).resolve();root=Path(sys.argv[2]).resolve()
if not (root/'apps/api/pom.xml').is_file():raise SystemExit('STOP: wrong repository root')
with zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('manifest.json'))
 for name in m['files']:
  target=root/name
  if '..' in Path(name).parts or not name.startswith(('apps/web/','apps/api/')) or target.is_symlink():raise SystemExit('STOP: invalid path '+name)
  if not target.is_file():raise SystemExit('STOP: missing '+name)
  actual=hashlib.sha256(target.read_bytes()).hexdigest()
  if actual!=m['original_sha256'][name]:
   if actual==m['new_sha256'][name]:print('ALREADY APPLIED:',name);continue
   raise SystemExit('STOP: file differs from inspected V44 version: '+name)
 stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
 backup=root/'.kbp-patch-backups'/('v44-compile-'+stamp)
 changed=[]
 for name in m['files']:
  target=root/name
  if hashlib.sha256(target.read_bytes()).hexdigest()==m['new_sha256'][name]:continue
  b=backup/name;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(target.read_bytes())
  stage=target.with_name(target.name+'.kbp-compile-new')
  if stage.exists():raise SystemExit('STOP: temporary file exists: '+str(stage))
  try:
   stage.write_bytes(z.read('overlay/'+name));os.replace(stage,target)
  finally:
   if stage.exists():stage.unlink()
  changed.append(name)
 print('V44 COMPILE FIX APPLIED:',len(changed),'files')
 print('Backups:',backup if changed else 'none (already applied)')
 for name in changed:print(' UPDATED:',name)
 print('No database changes. Run frontend type-check and isolated Commerce tests.')
