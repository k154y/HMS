Fixes TS2367 in CommercePanel and 8 Java test compilation failures after multi-role API change. Apply with python3 apply.py archive.zip /repo. No database changes.
