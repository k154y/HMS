# KBP compact purchasing and POS (rebased on the user's exact file)
- Scrollable compact cart for 20+ lines; per-row quantity and edit action.
- One expanded details editor at a time (unit, authorized override, discounts, note).
- Sticky backend-based review panel on desktop and stacked layout on narrow screens.
- Preserves existing CommerceInvoice, CommerceReceivingForm, shift and audit behavior.
- The unwanted "Business receipt. Not an official Rwanda EBM invoice." text was already absent in this user's file and remains absent.
- Does not change backend, migrations, or printed invoice templates in other files.
- TSX syntax verification passed. Full Next.js typecheck and manual transaction checks still required.
- Installer backs up exact current file and fails closed if it has changed.
