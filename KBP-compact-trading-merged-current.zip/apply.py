#!/usr/bin/env python3
import argparse,hashlib,pathlib,shutil,sys,time,zipfile
P='apps/web/components/commerce/CommerceTrading.tsx'
BASE='ec6de4944a2243a588dd8fd060a27e7f3e1e5386423cdb6fe92628d557292e59'
NEW='01bae0b9cf31c962411cb0e732b3a788d68e95fa2c4978fe380f30a54450a3b7'
def sha(x): return hashlib.sha256(x).hexdigest()
def main():
    p=argparse.ArgumentParser(description='KBP compact Trading UI install')
    p.add_argument('archive');p.add_argument('repository');p.add_argument('--check',action='store_true');a=p.parse_args()
    repo=pathlib.Path(a.repository).resolve();target=repo/P
    if not (repo/'apps/web/package.json').is_file() or not target.is_file(): sys.exit('STOP: Invalid KBP repository or missing Trading component')
    with zipfile.ZipFile(a.archive) as z: data=z.read('overlay/'+P)
    if sha(data)!=NEW: sys.exit('STOP: Patch checksum mismatch')
    now=sha(target.read_bytes())
    if now==NEW: print('ALREADY APPLIED: no changes');return
    if now!=BASE: sys.exit('CONFLICT: CommerceTrading.tsx has changed since the supplied ZIP; no files changed. Upload its latest version for a safe merge.')
    print('CHECK OK: Current file matches the uploaded source.')
    if a.check:return
    backup=repo/'.kbp-patch-backups'/('compact-ui-'+time.strftime('%Y%m%d-%H%M%S'))/P
    backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,backup)
    tmp=target.with_name(target.name+'.kbp-new');tmp.write_bytes(data)
    if sha(tmp.read_bytes())!=NEW:tmp.unlink(missing_ok=True);sys.exit('STOP: Temporary output checksum mismatch')
    tmp.replace(target)
    print('SUCCESS: Compact purchasing and POS layout applied.')
    print('Backup:',backup)
    print('Verify: cd apps/web && npx tsc --noEmit')
if __name__=='__main__': main()
