#!/usr/bin/env python3
import argparse, pathlib, hashlib, zipfile, time, shutil,sys
p=argparse.ArgumentParser();p.add_argument('archive');p.add_argument('repository');p.add_argument('--check',action='store_true');a=p.parse_args()
rel='apps/web/components/commerce/CommerceTrading.tsx'
root=pathlib.Path(a.repository).resolve();target=root/rel
if not (root/'apps/web/package.json').is_file() or not target.exists():sys.exit('STOP: wrong repository or source file missing')
with zipfile.ZipFile(a.archive) as z:replace=z.read('overlay/'+rel)
h=lambda b:hashlib.sha256(b).hexdigest()
if h(replace)!='75cc6b27d3eea9fe7e60cecb4f6f8ebfe0c1e596f9a2c00a34efd0ca0e99c4ce':sys.exit('STOP: invalid patch content')
old=h(target.read_bytes())
if old=='75cc6b27d3eea9fe7e60cecb4f6f8ebfe0c1e596f9a2c00a34efd0ca0e99c4ce':print('ALREADY APPLIED');sys.exit(0)
if old!='01bae0b9cf31c962411cb0e732b3a788d68e95fa2c4978fe380f30a54450a3b7':sys.exit('CONFLICT: local CommerceTrading.tsx differs. Nothing changed; upload the newer file for a safe merge.')
print('CHECK OK: exact source version matched')
if not a.check:
 backup=root/'.kbp-patch-backups'/('pos-modal-'+time.strftime('%Y%m%d-%H%M%S'))/rel
 backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,backup)
 temp=target.with_name(target.name+'.kbp-modal-next');temp.write_bytes(replace);temp.replace(target)
 print('SUCCESS: POS modal and visible units installed; backup:',backup)
