# KBP Commerce follow-up patch (V44)

This is an **additive patch against the exact post-V43 Commerce snapshot** previously uploaded.
It is NOT the full KBP repository. It does not touch existing Flyway migration files.

## What it changes
- One shared Product Editor for Create and Edit; single Save for product details, prices, units and optional branch price.
- Product base unit pricing: cost, retail, wholesale, minimum. Use bottle or kg as the smallest stock base unit for **new** products; configure crate (24 bottles) / bag (25 kg) as a larger selling unit with separate unit prices. Selling 0.5 crate deducts 12 bottles at half the crate price.
- Existing products with CRATE/BAG as base stock unit are **not silently rebased**; the editor warns because stock and sales history may exist.
- Existing-owner explicit action to enable required core Commerce entitlements; separate owner approval of opening inventory remains mandatory for financial posting.
- Multiple employee roles per account, with business and branch scoping and no delegated OWNER role. Preserves existing primary role, adds multi-role table in V44 and backfills existing staff.
- Improves checkout confirmation and retains existing receipt reprinting under Sales History.

## Apply safely in WSL Ubuntu
1. Download the ZIP into `C:\Users\k.yves\Downloads`.
2. Run:

```bash
cd /mnt/c/Users/k.yves/Desktop/projects/HMS
cp /mnt/c/Users/k.yves/Downloads/KBP-commerce-owner-products-staff-V44.zip .
unzip -p KBP-commerce-owner-products-staff-V44.zip apply.py > /tmp/kbp-v44-apply.py
python3 /tmp/kbp-v44-apply.py "$PWD/KBP-commerce-owner-products-staff-V44.zip" "$PWD"
```

If STOP/CONFLICT appears, do not force/overwrite; provide the output to review.
Do not `git reset`, `git clean` or discard untracked Commerce sources.

## Verify before restarting
- From WSL: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\Users\k.yves\Desktop\projects\HMS\scripts\test-hms-consistency.ps1' -ContainerBuild -Tests 'CommerceTradingTest'`.
- From running VS Code Dev Container: `cd /workspace/apps/web && npx tsc --noEmit`.
- Back up the **local development** PostgreSQL database before startup since Flyway V44 is pending.
- Restart ONLY development applications using existing scripts; check backend health and V44 in `flyway_schema_history`.

## Acceptance
- Owner of existing MSHOP should see **Enable purchasing and sales** if operational entitlements disabled.
- Then separately **Approve opening inventory valuation** if required.
- Use product base unit bottle: cost 500, retail 1,000 per bottle; crate 24 bottles wholesale 20,000. Selling 0.5 crate must charge 10,000 and deduct 12 bottles.
- Assign CASHIER and STOREKEEPER to one staff account and verify branch access, sale, receiving and denied product editing.
- Complete sale and open Print receipt in Sales History.
