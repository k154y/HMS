#!/usr/bin/env python3
"""Apply KBP patch only to the inspected source snapshot, preserving local work."""
import pathlib,hashlib,json,zipfile,sys,datetime,os
if len(sys.argv)!=3:raise SystemExit('Usage: python3 apply.py PATCH.zip /path/to/HMS-repository')
archive=pathlib.Path(sys.argv[1]).resolve();repo=pathlib.Path(sys.argv[2]).resolve()
if not (repo/'apps/api/pom.xml').is_file():raise SystemExit('ERROR: not the KBP repository root')
with zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('manifest.json'))
 for n in m['files']:
  target=repo/n
  if target.is_symlink():raise SystemExit('STOP: refusing symlink at '+n)
  if n in m['original_sha256']:
   if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=m['original_sha256'][n]:
    raise SystemExit('STOP: local file differs; no changes applied: '+n)
  elif target.exists():raise SystemExit('STOP: expected new file already exists: '+n)
  if not n.startswith(('apps/api/','apps/web/','docs/')) or '..' in pathlib.PurePosixPath(n).parts:
   raise SystemExit('STOP: unsafe file path '+n)
 stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
 backup=repo/'.kbp-patch-backups'/('commerce-unified-'+stamp)
 for n in m['original_sha256']:
  dest=backup/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((repo/n).read_bytes())
 for n in m['files']:
  dest=repo/n;dest.parent.mkdir(parents=True,exist_ok=True)
  content=z.read('overlay/'+n)
  stage=dest.with_name(dest.name+'.kbp-new')
  try:
   if stage.exists():raise SystemExit('STOP: temporary path occupied: '+str(stage))
   stage.write_bytes(content);os.replace(stage,dest)
  finally:
   if stage.exists():stage.unlink()
 print('PATCH APPLIED. Backups:',backup)
 print('Changed:',len(m['files']),'files. Do NOT restart until isolated tests and local DB backup.')
