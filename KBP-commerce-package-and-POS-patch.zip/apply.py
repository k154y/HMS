#!/usr/bin/env python3
"""Apply only if target files still match the inspected source archive."""
import pathlib,hashlib,json,zipfile,sys,datetime
archive=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
repo=pathlib.Path(sys.argv[2]).resolve() if len(sys.argv)>2 else pathlib.Path.cwd().resolve()
if not archive or not (repo/'apps/api/pom.xml').exists():
 raise SystemExit('Usage: python3 apply.py PATCH.zip /workspace (must be repository root)')
with zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('manifest.json'))
 for n in m['files']:
  f=repo/n
  if f.is_symlink(): raise SystemExit('Refusing symlink: '+n)
  if n in m['original_sha256']:
   if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=m['original_sha256'][n]:
    raise SystemExit('STOP: local file differs from inspected archive; nothing changed: '+n)
  elif f.exists():raise SystemExit('STOP: new migration already exists; nothing changed: '+n)
 stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
 backup=repo/'.kbp-patch-backups'/('package-pricing-'+stamp)
 for n in m['original_sha256']:
  out=backup/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((repo/n).read_bytes())
 for n in m['files']:
  f=repo/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read('overlay/'+n))
 print('Applied package pricing patch. Backup:',backup)
 print('DO NOT restart backend before reviewing changes and backing up local DB.')
