#!/usr/bin/env python3
"""Safety-first V45 KBP Commerce overlay installer. No Git or database operations."""
import hashlib,json,os,sys,zipfile,datetime
from pathlib import Path

def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    if len(sys.argv)<3 or len(sys.argv)>4 or (len(sys.argv)==4 and sys.argv[3]!='--check'):
        print('Usage: python3 apply.py <patch.zip> <repo-root> [--check]');return 2
    archive=Path(sys.argv[1]).resolve();repo=Path(sys.argv[2]).resolve()
    check=len(sys.argv)==4
    if not archive.is_file() or not (repo/'apps/api').is_dir() or not (repo/'apps/web').is_dir():
        print('STOP: Wrong ZIP or repository root. No changes made.');return 2
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('manifest.json'));planned=[];conflicts=[]
        for rel,info in manifest['files'].items():
            target=(repo/rel).resolve()
            if not target.is_relative_to(repo):
                conflicts.append(f'{rel}: invalid target path');continue
            payload=z.read('overlay/'+rel)
            if sha(payload)!=info['after']:
                conflicts.append(f'{rel}: archive integrity check failed');continue
            if not target.exists():
                if info['before'] is not None: conflicts.append(f'{rel}: source file missing')
                else:planned.append((rel,target,payload,None))
                continue
            if not target.is_file():
                conflicts.append(f'{rel}: target is not a file');continue
            actual=target.read_bytes();hashval=sha(actual)
            if hashval==info['after']:
                print('ALREADY UPDATED:',rel);continue
            if hashval==info['before']:
                planned.append((rel,target,payload,actual));continue
            conflicts.append(f'{rel}: local file differs from inspected V44 source')
        if conflicts:
            print('\nSTOP: Conflicts detected. NO files modified:')
            for entry in conflicts:print('  -',entry)
            print('Send this output back; do not force overwrite existing changes.')
            return 3
        if not planned:
            print('SUCCESS: All V45 files are already installed.');return 0
        for rel,*_ in planned:print(('WOULD APPLY: ' if check else 'APPLY: ')+rel)
        if check:
            print('CHECK PASSED: no changes made.');return 0
        stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
        backups=repo/'.kbp-patch-backups'/('commerce-v45-'+stamp)
        for rel,target,payload,old in planned:
            if old is not None:
                output=backups/rel;output.parent.mkdir(parents=True,exist_ok=True)
                output.write_bytes(old)
        for rel,target,payload,old in planned:
            target.parent.mkdir(parents=True,exist_ok=True)
            temp=target.with_name(target.name+'.v45tmp')
            if temp.exists():
                print('STOP: temporary file already exists:',temp);return 4
            try:
                temp.write_bytes(payload)
                if sha(temp.read_bytes())!=sha(payload):raise OSError('temporary file integrity failure')
                os.replace(temp,target)
            finally:
                if temp.exists():temp.unlink()
        print('SUCCESS: V45 code patch installed. Backups:',backups)
        print('NO services restarted and NO database migrations executed by the installer.')
        return 0

if __name__=='__main__':sys.exit(main())
