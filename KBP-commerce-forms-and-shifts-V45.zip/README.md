# KBP Commerce V45 – catalog-driven purchasing, POS and shift UX

Built against the **V44 owner-products-staff patch + V44 compile hotfix**. The installer refuses edits to files changed since those patches. Apply to your WSL repository only; this archive does not run Flyway or any production operation.

## Features
- Same create/edit form with one Save and real purchase-unit pricing (crate, bag, box, roll, bottle, kilogram, etc.)
- Multiple package sizes in one transactional Save, with distinct purchase/wholesale/retail prices
- Base-unit cost derived automatically; purchases use registered package cost without retyping
- Purchasing and POS choose only active products from existing catalog; barcode/SKU search; stock balances shown in POS
- Supplier purchase date, product-level discounts (percentage or amount), approved price overrides
- Purchase receiving records accepted, damaged and missing quantities separately; only accepted stock is sellable
- Customer returns from posted sale, product return window and original invoice price snapshots preserved
- Owner can create missing cash account from Shift screen; shift opening requires accounting active, branch and no other open shift
- POS offers automatic full-payment tender (cash shift, Mobile Money, bank or card) and clear checkout-to-receipt action
- V45 migration for package purchase prices, receiving claims, supplier date, product policies and return-policy snapshot

## WSL installation
1. Download ZIP to Windows Downloads.
2. `cd /mnt/c/Users/k.yves/Desktop/projects/HMS`
3. `cp /mnt/c/Users/k.yves/Downloads/KBP-commerce-forms-and-shifts-V45.zip .`
4. `unzip -p KBP-commerce-forms-and-shifts-V45.zip apply.py > /tmp/kbp-v45-apply.py`
5. Preview: `python3 /tmp/kbp-v45-apply.py "$PWD/KBP-commerce-forms-and-shifts-V45.zip" "$PWD" --check`
6. If CHECK PASSED: `python3 /tmp/kbp-v45-apply.py "$PWD/KBP-commerce-forms-and-shifts-V45.zip" "$PWD"`

If STOP/CONFLICT, do not overwrite files; provide the message for reconciliation. No git reset/clean is required.

## Verify *before* development restart
- Dev Container: `cd /workspace/apps/web && npx tsc --noEmit`
- WSL: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\Users\k.yves\Desktop\projects\HMS\scripts\test-hms-consistency.ps1' -ContainerBuild -Tests 'CommerceTradingTest,CommerceConfigurationTest'`
- Test script uses disposable containers / integration database. Do not point it at production.
- Check a current backup of local `hotel_hms` before allowing Flyway V45 to apply on backend restart.
- Check `flyway_schema_history` for V45 and `/actuator/health` after restart.

## Functional verification
1. Open MSHOP as OWNER; confirm RETAIL/ACCOUNTING modules enabled and Accounting active.
2. Products → Create Fanta with base bottle, crate=24, purchase/crate=10000, wholesale/crate=12000, retail/bottle=1200. Save once.
3. Purchasing → select Fanta, 30 crates, RWF, supplier, date. Review: total=300000 before tax/discount. Post and separately receive: 28 accepted, 2 damaged. Sellable increases by 672 bottles, supplier claim records 2 damaged crates.
4. Cashier shifts → create cash account if none, then Open shift (opening cash may be 0). Check no second concurrent shift for same cashier.
5. POS → select Fanta from catalog, choose bottle or crate, retail/wholesale and quantity. Review automatic prices/taxes. Complete sale only after valid tender and open cash shift if cash. Print saved receipt from confirmation / history.

**Important:** supplier claims do NOT automatically settle supplier payables or create supplier refunds. They record the discrepancy; a separate approved supplier-credit/refund workflow is still needed. Likewise a returned damaged customer item is not restored to sellable stock.

Test results: frontend TypeScript syntax and local isolated type assertions were checked. **Maven integration tests and your full Next.js TypeScript build have not been run in this environment.**
